const express = require('express')

const router = express.Router();

const {Items} = require('../models/item');


router.get('/', (req, res) => {
  res.render('index')
});
router.get('/view', (req, res) => {
  Items.find()
    .then(items => {
      res.render('view', { items1: items}); // Pass items or an empty array to the template
    })
    .catch(err => {
      console.error('Error fetching items:', err);
      res.status(500).send('Error fetching items');
    });
});


//Form Submission

router.post('/submit', (req, res) => {
  const newItem = new Items({
    name: req.body.name,
    description: req.body.description
  });

  newItem.save()
    .then(() => {
      console.log('Item saved successfully.');
      res.redirect('/');
    })
    .catch(err => {
      console.error('Error saving item:', err);
      res.status(500).send('Error saving item');
    });

    // const newItem = new Item({ name, description });


    // await newItem.save()
    // .then(() => {
    //   console.log('Item saved successfully.');
    //   res.redirect('/');
    // })
    // .catch((err) => {
    //   console.error('Error saving item:',err);
    //   res.status(500).send('Error saving item');
    // });
});


module.exports = router;
