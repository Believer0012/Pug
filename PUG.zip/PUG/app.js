const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const {Items} = require('./models/item'); // Assuming you have a model named Item
const routerFile = require('./routes/index');
const app = express();

// Connect to MongoDB using useNewUrlParser and useUnifiedTopology options
mongoose.connect('mongodb://0.0.0.0:27017/pug', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log('Connected to MongoDB');
  })
  .catch((error) => {
    console.error('Error connecting to MongoDB:', error.message);
  });

// Setup body-parser
app.use(bodyParser.urlencoded({ extended: true }));

// Set the view engine to Pug
app.set('view engine', 'pug');
app.set('views', './views');

// Define a route to display the form
app.get('/', (req, res) => {
  res.render('index');
});

// Define a route to handle form submission
// app.post('/submit', (req, res) => {
//   const { name, description } = req.body;
//   const newItem = new Items({ name, description });

//   newItem.save((err) => {
//     if (err) {
//       console.error('Error saving item:', err);
//       res.status(500).send('Error saving item');
//     } else {
//       console.log('Item saved successfully.');
//       res.redirect('/');
//     }
//   });
// });

// app.post('/submit', (req,res)=>{
// var res=new Items({
//   name:req.body.name,
//   description:req.body.description
// })
//   res.save()
 
// })
// app.post('/submit',(req,res)=>{
//   var res=new Items({
//     name:req.body.name,
//     description:req.body.description

//   })
//   res.save()
// })
// app.post('/submit', (req, res) => {
//   const newItem = new Items({
//     name: req.body.name,
//     description: req.body.description
//   });

//   newItem.save()
//     .then(() => {
//       console.log('Item saved successfully.');
//       res.redirect('/');
//     })
//     .catch(err => {
//       console.error('Error saving item:', err);
//       res.status(500).send('Error saving item');
//     });
// });
app.post("/submit" , routerFile)

// app.get('/', (req, res) => {
//   Items.find().toArray()
//     .then(items => {
//       res.render('index', {items1: items}); // Pass items or an empty array to the template
//     })
//     .catch(err => {
//       console.error('Error fetching items:', err);
//       res.status(500).send('Error fetching items');
//     });
// });
app.get("/" , routerFile)

app.get("/view",routerFile)


// app.get("/", (req, res) => {
//   Items.find().exec((err, items) => {
//     if (err) {
//       console.error('Error:', err);
//     } else {
//       res.render('index', { items1: items });
//     }
//     console.log('Items:', items);
//   });
// });
const PORT = process.env.PORT || 5001;
app.listen(PORT, () => {
  console.log(`Server running at port ${PORT}`);
});
